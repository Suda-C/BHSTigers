package com.example.bhs_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
